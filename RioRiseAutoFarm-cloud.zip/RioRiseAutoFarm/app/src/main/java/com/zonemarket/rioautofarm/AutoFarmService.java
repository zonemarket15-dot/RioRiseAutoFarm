package com.zonemarket.rioautofarm;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;

public class AutoFarmService extends AccessibilityService {
    private WindowManager wm; private View panel; private Button toggle; private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running=false; private SharedPreferences prefs; private String currentPackage=""; private String packageAtStart="";
    private final Runnable tapLoop = new Runnable() { @Override public void run() {
        if (!running) return;
        if (currentPackage.isEmpty() || !currentPackage.equals(packageAtStart) || currentPackage.equals(getPackageName())) { stopFarm(); return; }
        int x=prefs.getInt("x",540), y=prefs.getInt("y",1900), interval=prefs.getInt("interval",10);
        Path path=new Path(); path.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,80)).build();
        dispatchGesture(gesture,null,null);
        status.setText("AUTO FARM: ACTIVO · próximo toque en " + interval + " s");
        handler.postDelayed(this, interval*1000L);
    }};
    @Override protected void onServiceConnected() { super.onServiceConnected(); prefs=getSharedPreferences("farm",MODE_PRIVATE); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showPanel(); }
    private void showPanel() {
        if(panel!=null) return;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(14,10,14,10); box.setBackgroundColor(0xEE172033);
        TextView title=new TextView(this); title.setText("⛏️ RIO AUTO FARM"); title.setTextColor(0xFFFFFFFF); title.setTextSize(14); box.addView(title);
        status=new TextView(this); status.setText("AUTO FARM: DETENIDO"); status.setTextColor(0xFFFFFFFF); status.setTextSize(12); box.addView(status);
        toggle=new Button(this); toggle.setText("INICIAR"); toggle.setAllCaps(false); box.addView(toggle);
        Button hide=new Button(this); hide.setText("OCULTAR MENÚ"); hide.setAllCaps(false); box.addView(hide);
        toggle.setOnClickListener(v -> { if(running){ stopFarm(); } else { if(currentPackage.isEmpty() || currentPackage.equals(getPackageName())) { status.setText("Abre Rio Rise y vuelve a pulsar INICIAR"); return; } packageAtStart=currentPackage; running=true; toggle.setText("DETENER"); status.setText("AUTO FARM: ACTIVO"); handler.post(tapLoop); } });
        hide.setOnClickListener(v -> { stopFarm(); removePanel(); });
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END; lp.x=16; lp.y=180;
        panel=box; try { wm.addView(panel,lp); } catch(Exception e){panel=null;}
    }
    private void stopFarm(){ running=false; handler.removeCallbacks(tapLoop); if(toggle!=null) toggle.setText("INICIAR"); if(status!=null) status.setText("AUTO FARM: DETENIDO"); }
    private void removePanel(){ if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){} panel=null;} }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { if(event != null && event.getPackageName() != null) currentPackage=event.getPackageName().toString(); }
    @Override public void onInterrupt() { stopFarm(); }
    @Override public void onDestroy() { stopFarm(); removePanel(); super.onDestroy(); }
}
