package com.zonemarket.rioautofarm;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    EditText xInput, yInput, intervalInput;
    SharedPreferences prefs;
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("farm", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(24), dp(20), dp(20));
        root.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(this); title.setText("⛏️ Rio Rise Auto Farm"); title.setTextSize(24); title.setTextColor(0xFF152238); title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,dp(12)); root.addView(title, match());
        TextView note = new TextView(this); note.setText("Prototipo de toques repetidos. No modifica el juego ni detecta cuándo termina la animación: usa un intervalo aproximado."); note.setTextSize(14); note.setTextColor(0xFF455468); note.setPadding(0,0,0,dp(14)); root.addView(note, match());
        xInput = field("Coordenada X del botón de mina (px)", String.valueOf(prefs.getInt("x", 540)));
        yInput = field("Coordenada Y del botón de mina (px)", String.valueOf(prefs.getInt("y", 1900)));
        intervalInput = field("Intervalo entre toques (segundos; mínimo 3)", String.valueOf(prefs.getInt("interval", 10)));
        root.addView(xInput, match()); root.addView(yInput, match()); root.addView(intervalInput, match());
        Button save = button("Guardar configuración"); save.setOnClickListener(v -> save()); root.addView(save, match());
        Button overlay = button("Permitir mostrar menú flotante"); overlay.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); else Toast.makeText(this,"Permiso de menú flotante ya concedido",Toast.LENGTH_SHORT).show(); }); root.addView(overlay, match());
        Button access = button("Activar servicio de accesibilidad"); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access, match());
        TextView how = new TextView(this); how.setText("Uso: concede los dos permisos, vuelve al juego, abre el menú flotante y pulsa INICIAR. Ajusta X/Y para que coincidan con el botón de minería. Pulsa DETENER antes de salir."); how.setTextSize(14); how.setTextColor(0xFF152238); how.setPadding(0,dp(14),0,0); root.addView(how, match());
        setContentView(root);
    }
    EditText field(String hint, String value) { EditText e = new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint); e.setTextSize(15); e.setPadding(dp(12),dp(8),dp(12),dp(8)); e.setBackgroundColor(0xFFFFFFFF); e.setHintTextColor(0xFF7B8794); e.setTag(hint); LinearLayout.LayoutParams p = match(); p.bottomMargin=dp(8); e.setLayoutParams(p); return e; }
    Button button(String text) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); return b; }
    LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    void save() { try { int x=Integer.parseInt(xInput.getText().toString().trim()); int y=Integer.parseInt(yInput.getText().toString().trim()); int i=Integer.parseInt(intervalInput.getText().toString().trim()); if(x<0||y<0||i<3||i>3600) throw new NumberFormatException(); prefs.edit().putInt("x",x).putInt("y",y).putInt("interval",i).apply(); Toast.makeText(this,"Configuración guardada",Toast.LENGTH_SHORT).show(); } catch(Exception ex) { Toast.makeText(this,"Revisa X, Y e intervalo (mínimo 3 segundos)",Toast.LENGTH_LONG).show(); } }
}
