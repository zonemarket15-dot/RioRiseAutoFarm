# Compilar en la nube (GitHub Actions)

Este proyecto incluye `.github/workflows/build.yml` para compilar `app-debug.apk` en una máquina de GitHub Actions.

1. Entra a GitHub y crea un repositorio nuevo. Para reducir exposición, puede ser privado.
2. Sube el contenido de esta carpeta al repositorio (incluida la carpeta `.github/workflows`).
3. Abre la pestaña **Actions** y selecciona **Build RioRiseAutoFarm APK**.
4. Pulsa **Run workflow** y espera a que termine.
5. En la ejecución terminada, baja a **Artifacts** y descarga `RioRiseAutoFarm-debug-apk`.
6. Extrae el ZIP del artefacto; dentro estará `app-debug.apk`.

Si la compilación falla, abre el trabajo de compilación y copia el error final para revisarlo.

Nota: el APK es una aplicación auxiliar de toques repetidos con accesibilidad, no una modificación del APK de Rio Rise. Prueba solo con permisos que entiendas y detén el servicio antes de cambiar de app.
