# Rio Rise Auto Farm (prototipo Android)

Este proyecto es una aplicación auxiliar independiente; no modifica ni incluye el APK de Rio Rise.

## Qué hace
- Muestra un panel flotante usando el servicio de accesibilidad de Android.
- Repite un toque en una coordenada X/Y configurable, con intervalo de al menos 3 segundos.
- Se detiene si cambia la aplicación que está en primer plano, o si se pulsa DETENER.

## Limitaciones
- No reconoce cuándo termina la animación de minería; el intervalo es aproximado.
- Las coordenadas se miden en píxeles de pantalla y hay que ajustarlas en el teléfono.
- Android puede limitar servicios en segundo plano; mantén el juego abierto y prueba primero con intervalos largos.
- No incluye un APK compilado. Se necesita Android Studio/Android SDK para compilar.

## Compilar
1. Abre esta carpeta en Android Studio.
2. Deja que Gradle sincronice el proyecto.
3. Compila con Build > Build APK(s).
4. Instala el APK generado.

## Configuración en el teléfono
1. Abre la app y guarda X, Y e intervalo.
2. Pulsa Activar servicio de accesibilidad y activa “Rio Rise Auto Farm” en Ajustes.
3. Vuelve a Rio Rise, abre el panel flotante si aparece y pulsa INICIAR.
4. Prueba con un intervalo largo. Ajusta X/Y a la posición exacta del botón de minería.
5. Pulsa DETENER antes de cambiar de aplicación.

El permiso de accesibilidad permite simular toques en pantalla. Concédelo solo si entiendes y aceptas ese alcance.
